#!/usr/bin/env python

from distutils.core import setup

setup(name='Python MK-Livestatus parser',
      version='0.1',
      description='access MK livestatus query results either as lists or dictionaries',
      author='Michael Fladischer',
      author_email='michael@fladi.at',
      url='http://git.fladi.at/python-mk-livestatus/',
      packages=['mk_livestatus'],
)
