import socket

class Socket(object):

    def __init__(self, peer):
        if (len(peer) == 2):
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        else:
            self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.socket.connect(peer)

    def query(self, query):
        return Query(query, self.socket)

class Query(object):

    def __init__(self, query, socket):
        self.query = query
        self.socket = socket
        self.result = list()

    def _fetch(self):
        print "Sending %s\n" % self.query
        self.socket.send(self.query)
        self.socket.shutdown(socket.SHUT_WR)
        handle = self.socket.makefile()
        colpos = self.query.find("Columns:")
        if colpos > 0:
            compos = self.query.find("\n", colpos)
            if compos < 0:
                compos = len(self.query)
            columns = filter(bool, self.query[colpos+9:compos].split(' '))
        else:
            columns = handle.readline().split(';')
        for line in handle:
            self.result.append(dict(zip(columns, map(lambda (v): v.find(',') > 0 and v.strip(' \t\n\r').split(',') or v.strip(' \t\n\r'), line.split(';')))))

    def get_list(self):
        if not self.result:
            self._fetch()
        return self.result

    def get_dict(self, key):
        return dict(map(lambda (v): (v[key], v), self.get_list()))

